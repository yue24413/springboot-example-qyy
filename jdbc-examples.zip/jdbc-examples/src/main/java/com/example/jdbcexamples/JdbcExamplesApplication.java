package com.example.jdbcexamples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcExamplesApplication {
    public static void main(String[] args) {
        SpringApplication.run(JdbcExamplesApplication.class, args);
    }
}
