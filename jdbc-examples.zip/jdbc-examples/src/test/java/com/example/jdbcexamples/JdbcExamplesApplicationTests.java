package com.example.jdbcexamples;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcExamplesApplicationTests {

    @Test
    void contextLoads() {
    }

}
